import { createContext } from "react";

const ActivePageContext = createContext(null);

export default ActivePageContext;