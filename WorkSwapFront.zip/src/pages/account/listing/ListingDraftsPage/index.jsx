const ListingDraftsPage = () => {
    return (
        <div>
            <span>Тут типа должны быть черновики объявлений пользователя</span>
        </div>
    );
};

export default ListingDraftsPage;