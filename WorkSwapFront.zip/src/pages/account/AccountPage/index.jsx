const AccountPage = () => {
    return (
        <>
            <div className="account-header">
                <h2>Мой аккаунт</h2>
            </div>
        </>
    );
};

export default AccountPage;