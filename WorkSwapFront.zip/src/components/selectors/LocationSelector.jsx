import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/apiClient";

const LocationSelector = ({ locationId, onChange }) => {
    const [locations, setLocations] = useState([]);
    const [selectedPath, setSelectedPath] = useState([]);

    useEffect(() => {
        async function loadLocations() {
            const data = await apiFetch("/api/locations");

            const locs = data.locations || [];
            setLocations(locs);

            // если уже есть categoryId → восстановим путь
            if (locationId) {
                const path = findPathToLocation(locs, locationId);
                setSelectedPath(path);
            }
        }

        function findPathToLocation(locations, locationId) {
            const loc = locations.find(c => c.id === locationId);
            if (!loc) return [];

            // если есть parentId → рекурсивно ищем путь к родителю
            if (loc.countryIdId) {
                return [...findPathToLocation(locations, loc.parentId), loc.id];
            } else {
                return [loc.id];
            }
        }

        loadLocations();
    }, [locationId]);

    // нормализуем сравнение
    const getChildren = (countryId) =>
        locations.filter((c) => c.countryId === countryId);

    const handleSelect = (level, value) => {
        const newPath = [...selectedPath.slice(0, level), value];
        setSelectedPath(newPath);

        if (onChange) {
            onChange(value, newPath); // пробрасываем выбранный id и путь
        }
    };

    const renderSelectors = () => {
        const selectors = [];
        let countryId = null;

        for (let level = 0; ; level++) {
            const children = getChildren(countryId);
            if (children.length === 0) break;

            const selected = selectedPath[level] || "";
            selectors.push(
                <select
                    key={level}
                    value={selected}
                    onChange={(e) => handleSelect(level, Number(e.target.value))}
                >
                    <option value="" disabled>
                        Выберите локацию
                    </option>
                    {children.map((l) => (
                        <option key={l.id} value={l.id}>
                            {l.name}
                        </option>
                    ))}
                </select>
            );

            if (!selected) break; // пока не выбрали — дальше не идём
            countryId = selected;
        }

        return selectors;
    };

    return <div id="locations">{renderSelectors()}</div>;
};

export default LocationSelector;